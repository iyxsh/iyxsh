#ifndef INCLUDED_COM_SUN_STAR_AWT_COLORSTOPSEQUENCE_HPP
#define INCLUDED_COM_SUN_STAR_AWT_COLORSTOPSEQUENCE_HPP

#include "sal/config.h"

#include "com/sun/star/awt/ColorStopSequence.hdl"

#include "com/sun/star/awt/ColorStop.hpp"
#include "com/sun/star/uno/Sequence.hxx"
#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"


#endif // INCLUDED_COM_SUN_STAR_AWT_COLORSTOPSEQUENCE_HPP
