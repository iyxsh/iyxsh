#ifndef INCLUDED_COM_SUN_STAR_AWT_KEY_HPP
#define INCLUDED_COM_SUN_STAR_AWT_KEY_HPP

#include "com/sun/star/awt/Key.hdl"

#endif // INCLUDED_COM_SUN_STAR_AWT_KEY_HPP
