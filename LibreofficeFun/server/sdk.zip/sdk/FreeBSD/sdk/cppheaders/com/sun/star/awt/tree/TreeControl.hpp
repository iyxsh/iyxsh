#ifndef INCLUDED_COM_SUN_STAR_AWT_TREE_TREECONTROL_HPP
#define INCLUDED_COM_SUN_STAR_AWT_TREE_TREECONTROL_HPP

#include "sal/config.h"

#include "cppu/unotype.hxx"

namespace com { namespace sun { namespace star { namespace awt { namespace tree {

class TreeControl {
private:
    TreeControl(); // not implemented
    TreeControl(TreeControl &); // not implemented
    ~TreeControl(); // not implemented
    void operator =(TreeControl); // not implemented
};

} } } } }

#endif // INCLUDED_COM_SUN_STAR_AWT_TREE_TREECONTROL_HPP
